var indexSectionsWithContent =
{
  0: "abgt",
  1: "at",
  2: "abgt"
};

var indexSectionNames =
{
  0: "all",
  1: "classes",
  2: "functions"
};

var indexSectionLabels =
{
  0: "All",
  1: "Classes",
  2: "Functions"
};

