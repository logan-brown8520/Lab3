var searchData=
[
  ['getpoint',['getPoint',['../class_adafruit___f_t6206.html#a4ef0e1c061003dd83c4e21df4f8d547f',1,'Adafruit_FT6206']]]
];
