var searchData=
[
  ['touched',['touched',['../class_adafruit___f_t6206.html#a00858a298fcb2542164f054c8f665c1b',1,'Adafruit_FT6206']]]
];
